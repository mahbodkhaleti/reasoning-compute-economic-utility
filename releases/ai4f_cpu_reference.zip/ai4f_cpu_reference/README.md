# Compact anonymous AI4F source and CPU audit

The current paper is ai4f_workshop/paper.pdf; its source is ai4f_workshop/main.tex.
Run `bash reproduce_ai4f_workshop.sh` from this directory. Python 3.10+ and
Poppler are required; no GPU, model weights or model API is used.
With LaTeX, run `make -C ai4f_workshop` and `make -C ai4f_workshop audit`.

This bundle checks saved numerical evidence and the prospective CPU reference.
It excludes the full historical inference archive. Full experiment replay is
available in the complete repository. CPU fixtures are not independent model
or service validation. Read ai4f_workshop/cpu_reference/CONTRACT.md.
The workshop README's links to parent repository documentation and releases
require the full repository; the commands above work within this compact bundle.
